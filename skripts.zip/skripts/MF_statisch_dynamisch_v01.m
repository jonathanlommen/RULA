function Output = MF_statisch_dynamisch_v01(alpha,omega,Grenzen)
%%
% alpha = Data_tmp.jointAngle(:,3*(ind_joint-1)+1);
% omega = Data_tmp.v_jointAngle(:,3*(ind_joint-1)+1);
% 
Start_ind = find(diff(abs(omega)<Grenzen.Statisch_start)==1);% finden aller Frames, 
% wo die aktuelle Winkelgeschwindigkeit kleiner wird als die
% Grenzgeschwindigkeit.

if abs(omega(1)) < Grenzen.Statisch_start
    Start_ind = [1;Start_ind];
end

End_ind = find(diff(abs(omega)<Grenzen.Statisch_ende)==-1);
if isempty(End_ind)
    if abs(omega(end)) < Grenzen.Statisch_ende
        End_ind = size(omega,1);
    end
end
if End_ind(end)<Start_ind(end)
    End_ind = [End_ind; size(omega,1)];
end
if isempty(Start_ind)
    Output.statisch = zeros(size(alpha,1),1);
else
    if isempty(End_ind)
        if range(alpha) > Grenzen.Statisch_change
            Output.statisch = zeros(size(alpha,1),1);
        else
            Output.statisch = ones(size(alpha,1),1);
        end
    else
    Start_ind_tmp = Start_ind;
    Start_ind_tmp_fix = [];
    ind_int = 1;
    while ind_int <= size(Start_ind,1)
        Time_points = End_ind - Start_ind(ind_int);
        Time_points(Time_points < 0) = [];
        if ~isempty(Time_points)
        if Time_points(1) > Grenzen.Statisch_dauermin*Grenzen.sampling_rate
            Start_ind_tmp_fix = [Start_ind_tmp_fix; Start_ind(ind_int) Start_ind(ind_int) + Time_points(1)];
        end
        ind_int = find(Start_ind > (Start_ind(ind_int) + Time_points(1)));
        if isempty(ind_int)
            ind_int = size(Start_ind,1)+1;
        else ind_int = ind_int(1);
        end
        else
            Cont_ende = find(abs(alpha(Start_ind(ind_int):end)-alpha(Start_ind)) > Grenzen.Statisch_change);
            if ~isempty(Cont_ende)
                Start_ind_tmp_fix = [Start_ind_tmp_fix; Start_ind(ind_int) Start_ind(ind_int) + Cont_ende(1)];
            end
            ind_int = size(Start_ind,1)+1;
        end
        clear Time_points
    end
    Output.statisch = zeros(size(alpha,1),1);
    for ind_int = 1:size(Start_ind_tmp_fix,1)
        Output.statisch(Start_ind_tmp_fix(ind_int,1):Start_ind_tmp_fix(ind_int,2)) = 1;
    end
    if Output.statisch(end-1) == 1
        Output.statisch(end) = 1;
    end
    end
end
% %%
% figure(2)
% plot(omega)
% hold on
% plot(alpha)
% plot(Output.statisch,'.')
% hold off


%%
Speed_matrix = NaN * zeros(size(omega,1)+round(Grenzen.sampling_rate)-1,round(Grenzen.sampling_rate));
for ind_sampling = 1:round(Grenzen.sampling_rate)
    Speed_matrix(ind_sampling-1+(1:size(omega,1)),ind_sampling) = omega;
end
Speed_matrix = Speed_matrix(round(round(Grenzen.sampling_rate)/2)+0:size(omega,1),:);
edges = 0:1:Grenzen.hochdynamisch;
Bin_matrix = NaN*zeros(size(Speed_matrix,1),size(edges,2)-1);
for ind_edges = 1:size(Speed_matrix,1)
    Bin_matrix(ind_edges,:) = histcounts(abs(Speed_matrix(ind_edges,:)),edges);
end
% imagesc(Bin_matrix')
% plot(median(abs(Speed_matrix),2))
%%
% plot(sum(abs(Speed_matrix)>Grenzen.hochdynamisch,2))
Output.hochdynamisch = sum(abs(Speed_matrix)>Grenzen.hochdynamisch,2)>0;

% figure(2)
% plot(omega)
% hold on
% plot(alpha)
% plot(Output.statisch,'.')
% plot(Output.hochdynamisch,'.')
% hold off

% histcount
%%
if size(alpha,1)>10*Grenzen.sampling_rate
% figure(3)
% spectrogram(alpha,Grenzen.sampling_rate,[],[],Grenzen.sampling_rate)
% [s,f,t,ps] = spectrogram(alpha,2*Grenzen.sampling_rate,[],[],Grenzen.sampling_rate,'power');
% [s,f,t,ps] = spectrogram(alpha,Grenzen.sampling_rate,[],[],Grenzen.sampling_rate);
wind = kaiser(round(10*Grenzen.sampling_rate),17);
% plot(wind)
% hold on
% plot(kaiser(10*Grenzen.sampling_rate,5))
% hold off
%%
% f = .9;
% t = (1:(24*30))/24;
% alpha = sin(.2*2*pi*t)';
% % alpha(1:(24*2)) = 0;
% alpha(24*6+(1:(24*4))) = sin(.6*2*pi*(1:(24*4))/24)';
% alpha(24*10+(1:(24*2))) = sin(.2*2*pi*(1:(24*2))/24)';
% alpha(24*12+(1:(24*5))) = sin(.8*2*pi*(1:(24*5))/24)';
% plot(t,alpha)
% %
[s,f,t,ps] = spectrogram(alpha,wind,round(9*Grenzen.sampling_rate),[],Grenzen.sampling_rate);
% imagesc(abs(s))
% plot(f'*(ps)./sum(ps))
% ylim([0 2])
%
% freq = 
% plot(smooth((f(1:end)'*(ps(1:end,:)))./(sum(ps(1:end,:))),3))
rep_tmp = reshape(repmat(smooth(f'*(ps)./sum(ps),3)>Grenzen.meanpowerfrequency,1,round(Grenzen.sampling_rate))',[],1);
Output.repetitiv = zeros(size(alpha,1),1);
Output.repetitiv(floor(Grenzen.sampling_rate*4.5)+ ...
    (1:size(rep_tmp,1))) = rep_tmp;
Output.repetitiv(1:floor(Grenzen.sampling_rate*4.5)) = rep_tmp(1);
Output.repetitiv((floor(Grenzen.sampling_rate*4.5)+size(rep_tmp,1)+1):end) = rep_tmp(end);

% yyaxis left
% plot(alpha)
% yyaxis right
% plot(Output.repetitiv)
% hold on
% plot(sum(abs(s)))
% % plot(alpha)
% hold off

% %%
% figure
% ifq = instfreq(alpha,Grenzen.sampling_rate);
% plot(ifq)
else
    % automatically set to zero because short sequences under 10
    % seconds cannot be resolved reliably with this method.
    Output.repetitiv = zeros(size(alpha,1),1);
end
