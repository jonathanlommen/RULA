function Output = MF_2Drot(Input,alpha)

% Input is a 2 x n vector
if size(alpha,1) == 1 
Output(:,1) = sum(Input.*repmat([cos(alpha/180*pi) -sin(alpha/180*pi)],size(Input,1),1),2);
Output(:,2) = sum(Input.*repmat([sin(alpha/180*pi) cos(alpha/180*pi)],size(Input,1),1),2);
else
Output(:,1) = sum(Input.*[cos(alpha/180*pi) -sin(alpha/180*pi)],2);
Output(:,2) = sum(Input.*[sin(alpha/180*pi) cos(alpha/180*pi)],2);
end    