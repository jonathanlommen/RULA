%% Section A: Arm and Wrist Analysis.

hist_resolution = 1;

%% Step 1: Locate Upper Arm Position ("Upper arm score")
Side_name = {'right','left'};
Joint_index = [8 12;7 11];

for ind_side = 1:2
    % upper arm flexion
ind_joint = Joint_index(1,ind_side);
ind_dim = 3;
Limits = [-Inf -20 2;-20 20 1;20 45 2;45 90 3;90 Inf 4];
Input = Data_tmp.jointAngle(:,(ind_joint-1)*3+ind_dim);
if range(Input) < 1
    rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.flex_ext.N = 1;
    rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.flex_ext.edges = nanmean(Input);
else
[rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.flex_ext.N,...
    rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.flex_ext.edges] = ...
    histcounts(Input,min(Input):hist_resolution:max(Input));
end
rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.flex_ext.limits = Limits;
rula.s1_upper_arm_pos.(Side_name{ind_side}).part.flex_ext = MF_calc_RULA_score(Input,Limits);

% Adjust Abduction (right): >45� Abd. --> +1
ind_dim = 1;
Limits = [-Inf 45 0;45 Inf 1];
Input = Data_tmp.jointAngle(:,(ind_joint-1)*3+ind_dim);
if range(Input) < 1
    rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.abd.N = 1;
    rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.abd.edges = nanmean(Input);
else
[rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.abd.N,...
    rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.abd.edges] = ...
    histcounts(Input,min(Input):hist_resolution:max(Input));
end
rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.abd.limits = Limits;
rula.s1_upper_arm_pos.(Side_name{ind_side}).part.abd = MF_calc_RULA_score(Input,Limits);

% Adjust Shoulder raising (right): >5� Elevation im Schulterg�rtel --> +1
ind_joint = Joint_index(2,ind_side); 
ind_dim = 1;
Limits = [-Inf 5 0;5 Inf 1];
Input = Data_tmp.jointAngle(:,(ind_joint-1)*3+ind_dim);
if range(Input) < 1
    rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.ele.N = 1;
    rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.ele.edges = nanmean(Input);
else
[rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.ele.N,...
    rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.ele.edges] = ...
    histcounts(Input,min(Input):hist_resolution:max(Input));
end
rula.s1_upper_arm_pos_hist.(Side_name{ind_side}).part.ele.limits = Limits;
rula.s1_upper_arm_pos.(Side_name{ind_side}).part.ele = MF_calc_RULA_score(Input,Limits);

% Arm support --> -1 (general no support!)

% Score:
rula.s1_upper_arm_pos.(Side_name{ind_side}).total = rula.s1_upper_arm_pos.(Side_name{ind_side}).part.flex_ext + ...
    rula.s1_upper_arm_pos.(Side_name{ind_side}).part.ele + rula.s1_upper_arm_pos.(Side_name{ind_side}).part.abd;
end


%% Step 2: Locate Lower Arm Position ("Lower arm score")
Side_name = {'right','left'};
Joint_index = [9 13;10 14];
% get the orientation of the body based on the thoratic 8
ind_T8 = 5;
[T8_orient] = MF_Quaternion2Euler(Data_tmp.orientation(:,4*ind_T8+(1:4)));

for ind_side = 1:2
% lower arm flexion
ind_joint = Joint_index(1,ind_side); 
ind_dim = 3;
Limits = [-Inf 60 2;60 100 1;100 Inf 2];
Input = Data_tmp.jointAngle(:,(ind_joint-1)*3+ind_dim);
if range(Input) < 1
    rula.s2_lower_arm_pos_hist.(Side_name{ind_side}).part.flex_ext.N = 1;
    rula.s2_lower_arm_pos_hist.(Side_name{ind_side}).part.flex_ext.edges = nanmean(Input);
else
[rula.s2_lower_arm_pos_hist.(Side_name{ind_side}).part.flex_ext.N,...
    rula.s2_lower_arm_pos_hist.(Side_name{ind_side}).part.flex_ext.edges] = ...
    histcounts(Input,min(Input):hist_resolution:max(Input));
end
rula.s2_lower_arm_pos_hist.(Side_name{ind_side}).part.flex_ext.limits = Limits;
rula.s2_lower_arm_pos.(Side_name{ind_side}).part.flex_ext = MF_calc_RULA_score(Input,Limits);

% work outside the body center:
Arm_Null = Data_tmp.position(:,3*(Joint_index(2,ind_side)-1)+(1:2))-Data_tmp.position(:,3*(ind_T8-1)+(1:2));
Arm_Null_rot = MF_2Drot(Arm_Null,-T8_orient(:,3));

switch ind_side
    case 2
if isempty(Subject_tmp.Gender)
    Limits = [-Inf -.2 1;-.2 0 0;0 Inf 1];
    Input = Arm_Null_rot(:,2);
else
    if strcmp(Subject_tmp.Gender{:},'m')
        Limits = [-Inf -.2 1;-.2 0 0;0 Inf 1];
        Input = Arm_Null_rot(:,2);
    else
        Limits = [-Inf -.18 1;-.18 0 0;0 Inf 1];
        Input = Arm_Null_rot(:,2);
    end
end
    case 1
if isempty(Subject_tmp.Gender)
    Limits = [-Inf 0 1;0 0.2 0;0.2 Inf 1];
    Input = Arm_Null_rot(:,2);
else
    if strcmp(Subject_tmp.Gender{:},'m')
        Limits = [-Inf 0 1;0 0.2 0;0.2 Inf 1];
        Input = Arm_Null_rot(:,2);
    else
        Limits = [-Inf 0 1;0 0.18 0;0.18 Inf 1];
        Input = Arm_Null_rot(:,2);
    end
end
end
if range(Input) < .01
    rula.s2_lower_arm_pos_hist.(Side_name{ind_side}).part.pos2center.N = 1;
    rula.s2_lower_arm_pos_hist.(Side_name{ind_side}).part.pos2center.edges = nanmean(Input);
else
[rula.s2_lower_arm_pos_hist.(Side_name{ind_side}).part.pos2center.N,...
    rula.s2_lower_arm_pos_hist.(Side_name{ind_side}).part.pos2center.edges] = ...
    histcounts(Input,min(Input):(hist_resolution/100):max(Input));
end
rula.s2_lower_arm_pos_hist.(Side_name{ind_side}).part.pos2center.limits = Limits;
rula.s2_lower_arm_pos.(Side_name{ind_side}).part.pos2center = MF_calc_RULA_score(Input,Limits);

rula.s2_lower_arm_pos.(Side_name{ind_side}).total = ...
    rula.s2_lower_arm_pos.(Side_name{ind_side}).part.flex_ext + ...
    rula.s2_lower_arm_pos.(Side_name{ind_side}).part.pos2center;
end

%% Step 3 + 4: Locate Wrist Position ("Wrist score") ("Wrist twist")
Side_name = {'right','left'};
Joint_index = [10 14];

for ind_side = 1:2
% RIGHT WRIST SCORE.
% wrist flexion
ind_joint = Joint_index(1,ind_side); 
ind_dim = 3;
Limits = [-Inf -15 3;-15 -5 2;-5 5 1; 5 15 2;15 Inf 3];
Input = Data_tmp.jointAngle(:,(ind_joint-1)*3+ind_dim);
if range(Input) < 1
    rula.s3_wrist_pos_hist.(Side_name{ind_side}).part.flex_ext.N = 1;
    rula.s3_wrist_pos_hist.(Side_name{ind_side}).part.flex_ext.edges = nanmean(Input);
else
[rula.s3_wrist_pos_hist.(Side_name{ind_side}).part.flex_ext.N,...
    rula.s3_wrist_pos_hist.(Side_name{ind_side}).part.flex_ext.edges] = ...
    histcounts(Input,min(Input):hist_resolution:max(Input));
end
rula.s3_wrist_pos_hist.(Side_name{ind_side}).part.flex_ext.limits = Limits;
rula.s3_wrist_pos.(Side_name{ind_side}).part.flex_ext = MF_calc_RULA_score(Input,Limits);

% wrist deviation
ind_dim = 1;
Limits = [-Inf -10 1;-10 10 0;10 Inf 1];
Input = Data_tmp.jointAngle(:,(ind_joint-1)*3+ind_dim);
if range(Input) < 1
    rula.s3_wrist_pos_hist.(Side_name{ind_side}).part.dev.N = 1;
    rula.s3_wrist_pos_hist.(Side_name{ind_side}).part.dev.edges = nanmean(Input);
else
[rula.s3_wrist_pos_hist.(Side_name{ind_side}).part.dev.N,...
    rula.s3_wrist_pos_hist.(Side_name{ind_side}).part.dev.edges] = ...
    histcounts(Input,min(Input):hist_resolution:max(Input));
end
rula.s3_wrist_pos_hist.(Side_name{ind_side}).part.dev.limits = Limits;
rula.s3_wrist_pos.(Side_name{ind_side}).part.dev = MF_calc_RULA_score(Input,Limits);

rula.s3_wrist_pos.(Side_name{ind_side}).total = rula.s3_wrist_pos.(Side_name{ind_side}).part.dev + ...
    rula.s3_wrist_pos.(Side_name{ind_side}).part.flex_ext;


% wrist twist
ind_dim = 2;
Limits = [-Inf -45 2;-45 45 1;45 Inf 2];
Input = Data_tmp.jointAngle(:,(ind_joint-1)*3+ind_dim);
if range(Input) < 1
    rula.s4_wrist_pos_hist.(Side_name{ind_side}).part.twist.N = 1;
    rula.s4_wrist_pos_hist.(Side_name{ind_side}).part.twist.edges = nanmean(Input);
else
[rula.s4_wrist_pos_hist.(Side_name{ind_side}).part.twist.N,...
    rula.s4_wrist_pos_hist.(Side_name{ind_side}).part.twist.edges] = ...
    histcounts(Input,min(Input):hist_resolution:max(Input));
end
rula.s4_wrist_pos_hist.(Side_name{ind_side}).part.twist.limits = Limits;
rula.s4_wrist_pos.(Side_name{ind_side}).part.twist = MF_calc_RULA_score(Input,Limits);

rula.s4_wrist_pos.(Side_name{ind_side}).total = rula.s3_wrist_pos.(Side_name{ind_side}).total + ...
    rula.s4_wrist_pos.(Side_name{ind_side}).part.twist;
end

%% Step 5: "Wrist and arm Posture Score" in table A
% TableA = readtable('Wrist and Arm Posture Score.xlsx','Range','C4:J22');
for ind_side = 1:2
WristArmScore = reshape(Settings.RULA.TableA{:,:},[],1);
NoNaN = find(~isnan(reshape((rula.s1_upper_arm_pos.(Side_name{ind_side}).total + ...
    rula.s2_lower_arm_pos.(Side_name{ind_side}).total + ...
    rula.s3_wrist_pos.(Side_name{ind_side}).total + ...
    rula.s4_wrist_pos.(Side_name{ind_side}).part.twist),[],1)));

Tmp_UA = reshape(rula.s1_upper_arm_pos.(Side_name{ind_side}).total,[],1);
Tmp_LA = reshape(rula.s2_lower_arm_pos.(Side_name{ind_side}).total,[],1);
Tmp_WS = reshape(rula.s3_wrist_pos.(Side_name{ind_side}).total,[],1);
Tmp_WT = reshape(rula.s4_wrist_pos.(Side_name{ind_side}).part.twist,[],1);
Tmp_UA = Tmp_UA(NoNaN);
Tmp_LA = Tmp_LA(NoNaN);
Tmp_WS = Tmp_WS(NoNaN);
Tmp_WT = Tmp_WT(NoNaN);

Tmp_Score = WristArmScore((Tmp_WS-1)*3*6*2 + (Tmp_WT-1)*3*6 + (Tmp_UA-1)*3 + ...
    Tmp_LA);
rula.s5_arm_post_score.(Side_name{ind_side}).total = NaN*ones(size(rula.s1_upper_arm_pos.(Side_name{ind_side}).total));
rula.s5_arm_post_score.(Side_name{ind_side}).total(NoNaN) = Tmp_Score;
end


%% Step 6: Add �Muscle Use Score _ Arm and Wrist�
% static muscle work (e.g. longer than 10 seconds in the same position) 
% or repetitive work, > 4 rep / min => +1 

Limits_muscle.Statisch_start = 5; % static: start if omega < 5�/s, 
Limits_muscle.Statisch_ende = 10; % end if omega > 10�/s, 
Limits_muscle.Statisch_change = 7.5;% diff between start and end > 7.5� => end of static
Limits_muscle.Statisch_dauermin = 10; % static has to be longer than 10 seconds
Limits_muscle.sampling_rate = Subject_tmp.Parameter.frameRate;

% Heighdym_lim = [55 ]
% Limits_muscle f�r hochdynahmisch laut Entwicklungs zu Methodenpacket zur Gef�hrdungsanalyse
% physischer Belastung am Arbeitsplatz
% Grenzwert f�r 33% in einer Minute erreicht => gesamte Minute
% Hochdynamisch
% Kopf/Nacken 45 
% Schultergelenk/Oberarm 55 
% Ellenbogen/Unterarm 85 
% Handgelenk 60 
% R�cken 35

Side_name = {'right','left'};
Joint_index = [8 12; 11 15;9 13;10 14];
for ind_side = 1:2
% shoulder:
Limits_muscle.hochdynamisch = 55;
Limits_muscle.meanpowerfrequency = .5;
ind_joint = Joint_index(1,ind_side); 
% abduction
ind_dim = 1;
rula.s6_arm_muscle_use.(Side_name{ind_side}).part.shoulder_abd = MF_statisch_dynamisch_v01(...
    Data_tmp.jointAngle(:,3*(ind_joint-1)+ind_dim),...
    Data_tmp.v_jointAngle(:,3*(ind_joint-1)+ind_dim),Limits_muscle);
% flexion
ind_dim = 3;
rula.s6_arm_muscle_use.(Side_name{ind_side}).part.shoulder_flex = MF_statisch_dynamisch_v01(...
    Data_tmp.jointAngle(:,3*(ind_joint-1)+ind_dim),...
    Data_tmp.v_jointAngle(:,3*(ind_joint-1)+ind_dim),Limits_muscle);

ind_L5 = 2;
ind_Hand = Joint_index(2,ind_side); 
ind_dim = 3;
L5underHand = Data_tmp.position(:,3*(ind_L5-1)+ind_dim) < ...
    Data_tmp.position(:,3*(ind_Hand-1)+3);

rula.s6_arm_muscle_use.(Side_name{ind_side}).part.static = and(...
    and(rula.s6_arm_muscle_use.(Side_name{ind_side}).part.shoulder_abd.statisch,...
    rula.s6_arm_muscle_use.(Side_name{ind_side}).part.shoulder_flex.statisch),L5underHand);

rula.s6_arm_muscle_use.(Side_name{ind_side}).part.repetitiv = or(rula.s6_arm_muscle_use.(Side_name{ind_side}).part.shoulder_abd.repetitiv,...
    rula.s6_arm_muscle_use.(Side_name{ind_side}).part.shoulder_flex.repetitiv);

rula.s6_arm_muscle_use.(Side_name{ind_side}).part.total_shoulder = or(...
    rula.s6_arm_muscle_use.(Side_name{ind_side}).part.static,...
    rula.s6_arm_muscle_use.(Side_name{ind_side}).part.repetitiv);

% not used in RULA
% elbow
Limits_muscle.hochdynamisch = 85;
Limits_muscle.meanpowerfrequency = .5;
ind_joint = Joint_index(3,ind_side); 
% flexion
ind_dim = 3;
rula.s6_arm_muscle_use.(Side_name{ind_side}).part.ellbow_flex = MF_statisch_dynamisch_v01(...
    Data_tmp.jointAngle(:,3*(ind_joint-1)+ind_dim),...
    Data_tmp.v_jointAngle(:,3*(ind_joint-1)+ind_dim),Limits_muscle);
% rotation
ind_dim = 2;
rula.s6_arm_muscle_use.(Side_name{ind_side}).part.ellbow_rot = MF_statisch_dynamisch_v01(...
    Data_tmp.jointAngle(:,3*(ind_joint-1)+ind_dim),...
    Data_tmp.v_jointAngle(:,3*(ind_joint-1)+ind_dim),Limits_muscle);

% wrist
Limits_muscle.hochdynamisch = 60;
Limits_muscle.meanpowerfrequency = .5;
ind_joint = Joint_index(4,ind_side); 
% flexion
ind_dim = 3;
rula.s6_arm_muscle_use.(Side_name{ind_side}).part.wrist_flex = MF_statisch_dynamisch_v01(...
    Data_tmp.jointAngle(:,3*(ind_joint-1)+ind_dim),...
    Data_tmp.v_jointAngle(:,3*(ind_joint-1)+ind_dim),Limits_muscle);
% deviation
ind_dim = 1;
rula.s6_arm_muscle_use.(Side_name{ind_side}).part.wrist_dev = MF_statisch_dynamisch_v01(...
    Data_tmp.jointAngle(:,3*(ind_joint-1)+ind_dim),...
    Data_tmp.v_jointAngle(:,3*(ind_joint-1)+ind_dim),Limits_muscle);


end


%% Step 7: Add �Force/ Load Score _ Arm and Wrist� 
for ind_side = 1:2
    % no high loads assumed
    rula.s7_arm_muscle_load.(Side_name{ind_side}).total = 0; 
end
 
%% Step 8: �Wrist and Arm Score�
for ind_side = 1:2
    % no high loads assumed
    rula.s8_wrist_arm_score.(Side_name{ind_side}).total = ...
        rula.s5_arm_post_score.(Side_name{ind_side}).total + ...
        rula.s6_arm_muscle_use.(Side_name{ind_side}).part.total_shoulder + ...
        rula.s7_arm_muscle_load.(Side_name{ind_side}).total;
end

%% Step 9: Locate Neck Position ("Neck score")
% flexion
joint_neck = 5;
joint_head = 6;
ind_dim = 3;
Limits = [-Inf 0 4;0 10 1;10 20 2;20 Inf 3];
Input = Data_tmp.jointAngle(:,(joint_neck-1)*3+ind_dim)+...
    Data_tmp.jointAngle(:,(joint_neck-1)*3+ind_dim);
if range(Input) < 1
    rula.s9_neck_pos_hist.part.flex_ext.N = 1;
    rula.s9_neck_pos_hist.part.flex_ext.edges = nanmean(Input);
else
[rula.s9_neck_pos_hist.part.flex_ext.N,...
    rula.s9_neck_pos_hist.part.flex_ext.edges] = ...
    histcounts(Input,min(Input):hist_resolution:max(Input));
end
rula.s9_neck_pos_hist.part.flex_ext.limits = Limits;
rula.s9_neck_pos.part.flex_ext = MF_calc_RULA_score(Input,Limits);


% adjust twist
ind_dim = 2;
Limits = [-Inf -10 1;-10 10 0;10 Inf 1];
Input = Data_tmp.jointAngle(:,(joint_neck-1)*3+ind_dim)+...
    Data_tmp.jointAngle(:,(joint_neck-1)*3+ind_dim);
if range(Input) < 1
    rula.s9_neck_pos_hist.part.twist.N = 1;
    rula.s9_neck_pos_hist.part.twist.edges = nanmean(Input);
else
[rula.s9_neck_pos_hist.part.twist.N,...
    rula.s9_neck_pos_hist.part.twist.edges] = ...
    histcounts(Input,min(Input):hist_resolution:max(Input));
end
rula.s9_neck_pos_hist.part.twist.limits = Limits;
rula.s9_neck_pos.part.twist = MF_calc_RULA_score(Input,Limits);

% adjust side bend
ind_dim = 1;
Limits = [-Inf -10 1;-10 10 0;10 Inf 1];
Input = Data_tmp.jointAngle(:,(joint_neck-1)*3+ind_dim)+...
    Data_tmp.jointAngle(:,(joint_neck-1)*3+ind_dim);
if range(Input) < 1
    rula.s9_neck_pos_hist.part.lat.N = 1;
    rula.s9_neck_pos_hist.part.lat.edges = nanmean(Input);
else
[rula.s9_neck_pos_hist.part.lat.N,...
    rula.s9_neck_pos_hist.part.lat.edges] = ...
    histcounts(Input,min(Input):hist_resolution:max(Input));
end
rula.s9_neck_pos_hist.part.lat.limits = Limits;
rula.s9_neck_pos.part.lat = MF_calc_RULA_score(Input,Limits);

rula.s9_neck_pos.total = rula.s9_neck_pos.part.lat + ...
    rula.s9_neck_pos.part.twist + ...
    rula.s9_neck_pos.part.flex_ext;

%% Step 10: Locate Trunk Position (�Trunk score�)
% flexion
joint_vertebra = 1:4;
ind_dim = 3;
Limits = [-Inf 5 1;5 20 2;20 60 3;60 Inf 4];
Input = sum(Data_tmp.jointAngle(:,(joint_vertebra-1)*3+ind_dim),2);
if range(Input) < 1
    rula.s10_trunk_pos_hist.part.flex_ext.N = 1;
    rula.s10_trunk_pos_hist.part.flex_ext.edges = nanmean(Input);
else
[rula.s10_trunk_pos_hist.part.flex_ext.N,...
    rula.s10_trunk_pos_hist.part.flex_ext.edges] = ...
    histcounts(Input,min(Input):hist_resolution:max(Input));
end
rula.s10_trunk_pos_hist.part.flex_ext.limits = Limits;
rula.s10_trunk_pos.part.flex_ext = MF_calc_RULA_score(Input,Limits);



% adjust twist
ind_dim = 2;
Limits = [-Inf -10 1;-10 10 0;10 Inf 1];
Input = sum(Data_tmp.jointAngle(:,(joint_vertebra-1)*3+ind_dim),2);
if range(Input) < 1
    rula.s10_trunk_pos_hist.part.twist.N = 1;
    rula.s10_trunk_pos_hist.part.twist.edges = nanmean(Input);
else
[rula.s10_trunk_pos_hist.part.twist.N,...
    rula.s10_trunk_pos_hist.part.twist.edges] = ...
    histcounts(Input,min(Input):hist_resolution:max(Input));
end
rula.s10_trunk_pos_hist.part.twist.limits = Limits;
rula.s10_trunk_pos.part.twist = MF_calc_RULA_score(Input,Limits);

% adjust side bend
ind_dim = 1;
Limits = [-Inf -10 1;-10 10 0;10 Inf 1];
Input = sum(Data_tmp.jointAngle(:,(joint_vertebra-1)*3+ind_dim),2);
if range(Input) < 1
    rula.s10_trunk_pos_hist.part.lat.N = 1;
    rula.s10_trunk_pos_hist.part.lat.edges = nanmean(Input);
else
[rula.s10_trunk_pos_hist.part.lat.N,...
    rula.s10_trunk_pos_hist.part.lat.edges] = ...
    histcounts(Input,min(Input):hist_resolution:max(Input));
end
rula.s10_trunk_pos_hist.part.lat.limits = Limits;
rula.s10_trunk_pos.part.lat = MF_calc_RULA_score(Input,Limits);

rula.s10_trunk_pos.total = rula.s10_trunk_pos.part.lat + ...
    rula.s10_trunk_pos.part.twist + ...
    rula.s10_trunk_pos.part.flex_ext;

%% Step 11: Legs
% general leg and feet are supported
rula.s11_leg_pos.total = ones(size(rula.s1_upper_arm_pos.left.total));

%% Step 12: �Trunk Posture Score� in Table B

% TableB = readtable('Trunk Posture Score.xlsx','Range','B4:M10');
TrunkPostureScore = reshape(Settings.RULA.TableB{:,:},[],1);
NoNaN = find(~isnan(reshape((rula.s9_neck_pos.total + ...
    rula.s10_trunk_pos.total + ...
    rula.s11_leg_pos.total),[],1)));

Tmp_TS = reshape(rula.s10_trunk_pos.total,[],1);
Tmp_LS = reshape(rula.s11_leg_pos.total,[],1);
Tmp_NS = reshape(rula.s9_neck_pos.total,[],1);
Tmp_TS = Tmp_TS(NoNaN);
Tmp_LS = Tmp_LS(NoNaN);
Tmp_NS = Tmp_NS(NoNaN);

Tmp_Score = TrunkPostureScore((Tmp_TS-1)*2*6 + (Tmp_LS-1)*6 + Tmp_NS);
rula.s12_trunk_neck_leg_post_score.total = NaN*ones(size(rula.s10_trunk_pos.total));

rula.s12_trunk_neck_leg_post_score.total(NoNaN) = Tmp_Score;

%% Step 13: Add �Muscle Use Score _ Neck, Trunk, Leg�

Grenzen.Statisch_start = 5;
Grenzen.Statisch_ende = 10;
Grenzen.Statisch_change = 7.5;
Grenzen.Statisch_dauermin = 10;
Grenzen.sampling_rate = Subject_tmp.Parameter.frameRate;
% Grenzen f�r hochdynahmisch laut Entwicklungs zu Methodenpacket zur Gef�hrdungsanalyse
% physischer Belastung am Arbeitsplatz
% Grenzwert f�r 33% in einer Minute erreicht => gesamte Minute
% Hochdynamisch
% Kopf/Nacken 45 
% R�cken 35

% neck
Grenzen.hochdynamisch = 45;
Grenzen.meanpowerfrequency = .5;
ind_joint = [5 6];
ind_dim = 1;
rula.s13_trunk_neck_muscle_use.neck_abduction = MF_statisch_dynamisch_v01(...
    sum(Data_tmp.jointAngle(:,3*(ind_joint-1)+ind_dim),2),...
    sum(Data_tmp.v_jointAngle(:,3*(ind_joint-1)+ind_dim),2),Grenzen);
ind_dim = 2;
rula.s13_trunk_neck_muscle_use.neck_rotation = MF_statisch_dynamisch_v01(...
    sum(Data_tmp.jointAngle(:,3*(ind_joint-1)+ind_dim),2),...
    sum(Data_tmp.v_jointAngle(:,3*(ind_joint-1)+ind_dim),2),Grenzen);
ind_dim = 3;
rula.s13_trunk_neck_muscle_use.neck_flexion = MF_statisch_dynamisch_v01(...
    sum(Data_tmp.jointAngle(:,3*(ind_joint-1)+ind_dim),2),...
    sum(Data_tmp.v_jointAngle(:,3*(ind_joint-1)+ind_dim),2),Grenzen);

%
rula.s13_trunk_neck_muscle_use.neck_static = and(and(rula.s13_trunk_neck_muscle_use.neck_abduction.statisch,...
    rula.s13_trunk_neck_muscle_use.neck_rotation.statisch),rula.s13_trunk_neck_muscle_use.neck_flexion.statisch);
rula.s13_trunk_neck_muscle_use.neck_repetitiv = or(or(rula.s13_trunk_neck_muscle_use.neck_abduction.repetitiv,...
    rula.s13_trunk_neck_muscle_use.neck_rotation.repetitiv),rula.s13_trunk_neck_muscle_use.neck_flexion.repetitiv);


rula.s13_trunk_neck_muscle_use.neck = or(rula.s13_trunk_neck_muscle_use.neck_static,...
    rula.s13_trunk_neck_muscle_use.neck_repetitiv);

% Rumpf
Grenzen.hochdynamisch = 35;
Grenzen.meanpowerfrequency = .3;
ind_joint = [1:4];
ind_dim = 1;
rula.s13_trunk_neck_muscle_use.trunk_abduction = MF_statisch_dynamisch_v01(...
    sum(Data_tmp.jointAngle(:,3*(ind_joint-1)+ind_dim),2),...
    sum(Data_tmp.v_jointAngle(:,3*(ind_joint-1)+ind_dim),2),Grenzen);
ind_dim = 2;
rula.s13_trunk_neck_muscle_use.trunk_rotation = MF_statisch_dynamisch_v01(...
    sum(Data_tmp.jointAngle(:,3*(ind_joint-1)+ind_dim),2),...
    sum(Data_tmp.v_jointAngle(:,3*(ind_joint-1)+ind_dim),2),Grenzen);
ind_dim = 3;
rula.s13_trunk_neck_muscle_use.trunk_flexion = MF_statisch_dynamisch_v01(...
    sum(Data_tmp.jointAngle(:,3*(ind_joint-1)+ind_dim),2),...
    sum(Data_tmp.v_jointAngle(:,3*(ind_joint-1)+ind_dim),2),Grenzen);

%
rula.s13_trunk_neck_muscle_use.trunk_static = and(and(rula.s13_trunk_neck_muscle_use.trunk_abduction.statisch,...
    rula.s13_trunk_neck_muscle_use.trunk_rotation.statisch),rula.s13_trunk_neck_muscle_use.trunk_flexion.statisch);
rula.s13_trunk_neck_muscle_use.trunk_repetitiv = or(or(rula.s13_trunk_neck_muscle_use.trunk_abduction.repetitiv,...
    rula.s13_trunk_neck_muscle_use.trunk_rotation.repetitiv),rula.s13_trunk_neck_muscle_use.trunk_flexion.repetitiv);


rula.s13_trunk_neck_muscle_use.trunk = or(rula.s13_trunk_neck_muscle_use.trunk_static,...
    rula.s13_trunk_neck_muscle_use.trunk_repetitiv);

% die Zeile ist weil es vermutlich auch hier nur maximal einen Punkt zu
% vergeben gibt. 
rula.s13_trunk_neck_muscle_use.total = or(rula.s13_trunk_neck_muscle_use.trunk,...
    rula.s13_trunk_neck_muscle_use.neck);
%% Step 14: Add �Force/ Load Score _ Neck, Trunk, Leg� 

rula.s14_trunk_neck_muscle_use.total = 0;

%% Step 15: �Neck, Trunk, Leg Score�

rula.s15_neck_trunk_leg_score.total = rula.s12_trunk_neck_leg_post_score.total + ...
    rula.s13_trunk_neck_muscle_use.total + ...
    rula.s14_trunk_neck_muscle_use.total;
%%
Final_RULA = reshape(Settings.RULA.TableC{:,:},[],1);

for ind_side = 1:2
NoNaN = find(~isnan(reshape((rula.s15_neck_trunk_leg_score.total + ...
    rula.s8_wrist_arm_score.(Side_name{ind_side}).total),[],1)));

Tmp_NTL = reshape(rula.s15_neck_trunk_leg_score.total,[],1);
Tmp_WASR = reshape(rula.s8_wrist_arm_score.(Side_name{ind_side}).total,[],1);
Tmp_NTL = Tmp_NTL(NoNaN);
Tmp_WASR = Tmp_WASR(NoNaN);
Tmp_NTL(Tmp_NTL>=7) = 7;
Tmp_WASR(Tmp_WASR>=8) = 8;

Tmp_Score = Final_RULA((Tmp_NTL-1)*8 + Tmp_WASR);
rula.final_score.(Side_name{ind_side}) = NaN*ones(size(rula.s8_wrist_arm_score.(Side_name{ind_side}).total));
rula.final_score.(Side_name{ind_side})(NoNaN) = Tmp_Score;
end

% rechts und links Seite
NoNaN = find(~isnan(reshape((rula.s15_neck_trunk_leg_score.total + ...
    rula.s8_wrist_arm_score.right.total + rula.s8_wrist_arm_score.left.total),[],1)));

Tmp_NTL = reshape(rula.s15_neck_trunk_leg_score.total,[],1);
Tmp_WAS = reshape(rula.s8_wrist_arm_score.right.total + rula.s8_wrist_arm_score.left.total,[],1);
Tmp_NTL = Tmp_NTL(NoNaN);
Tmp_WAS = Tmp_WAS(NoNaN);
Tmp_NTL(Tmp_NTL>=7) = 7;
Tmp_WAS(Tmp_WAS>=8) = 8;

Tmp_Score = Final_RULA((Tmp_NTL-1)*8 + Tmp_WAS);

rula.final_score.together = NaN*ones(size(rula.s8_wrist_arm_score.(Side_name{ind_side}).total));
rula.final_score.together(NoNaN) = Tmp_Score;











