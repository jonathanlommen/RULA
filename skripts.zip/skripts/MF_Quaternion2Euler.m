function Euler = MF_Quaternion2Euler(varargin)
% Eulerangle as phi theta psi
% mit 
% 1 = psi = yaw (heading, pan, azimuth)
% 2 = tetha = pitch (elevation, tilt)
% 3 = phi = roll (bank) 

if size(varargin,2) == 1
    order = 1;
    qua = varargin{1};
elseif size(varargin,2) == 2
    qua = varargin{1};
    order = varargin{2};
end


Euler(:,1) = (2*atan((2*qua(:,3).*qua(:,4) + 2*qua(:,1).*qua(:,2))...
    ./(2*qua(:,1).^2 + 2*qua(:,4).^2 -1)))/2;
arg = (2*qua(:,2).*qua(:,4)-2*qua(:,1).*qua(:,3));
Euler(:,2) = -(asin(arg.*(abs(arg)<1)-1*(-1>arg)+1*(1<arg)));
Euler(:,3) = (2*atan((2*qua(:,2).*qua(:,3) + 2*qua(:,1).*qua(:,4))...
    ./(2*qua(:,1).^2 + 2*qua(:,2).^2 -1)))/2;
Euler(isnan(Euler(:,1)),1) = pi;
Euler(isnan(Euler(:,3)),3) = pi;
for ind = 1:3
    Euler(:,ind) = unwrap(Euler(:,ind));
end


Euler = Euler*180/pi;
if order == 1
elseif order == 2
    Euler = Euler(:,[3 2 1]);
end