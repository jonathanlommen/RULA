function rula = RULA_calc_scores_rel(rula)
Side_name = {'right','left'};

for ind_side = 1:2

    rula.s1_upper_arm_pos.(Side_name{ind_side}).total_rel = Calc_rel(rula.s1_upper_arm_pos.(Side_name{ind_side}).total);
    rula.s2_lower_arm_pos.(Side_name{ind_side}).total_rel = Calc_rel(rula.s2_lower_arm_pos.(Side_name{ind_side}).total);
    rula.s4_wrist_pos.(Side_name{ind_side}).total_rel = Calc_rel(rula.s4_wrist_pos.(Side_name{ind_side}).total);
    rula.s5_arm_post_score.(Side_name{ind_side}).total_rel = Calc_rel(rula.s5_arm_post_score.(Side_name{ind_side}).total);
    rula.s8_wrist_arm_score.(Side_name{ind_side}).total_rel = Calc_rel(rula.s8_wrist_arm_score.(Side_name{ind_side}).total);
    rula.final_score.([Side_name{ind_side} '_rel']) = Calc_rel(rula.final_score.(Side_name{ind_side}));
end

rula.s9_neck_pos.total_rel = Calc_rel(rula.s9_neck_pos.total);
rula.s10_trunk_pos.total_rel = Calc_rel(rula.s10_trunk_pos.total);
rula.s12_trunk_neck_leg_post_score.total_rel = Calc_rel(rula.s12_trunk_neck_leg_post_score.total);
rula.s15_neck_trunk_leg_score.total_rel = Calc_rel(rula.s15_neck_trunk_leg_score.total);
rula.final_score.together_rel = Calc_rel(rula.final_score.together);

end


function Output = Calc_rel(Input)
Unique_tmp = unique(Input);
for ind_uni = 1:size(Unique_tmp,1)
    Output(ind_uni,1) = Unique_tmp(ind_uni); %#ok<AGROW>
    Output(ind_uni,2) = sum(Input==Unique_tmp(ind_uni))/size(Input,1);%#ok<AGROW>
end
clear Unique_tmp
end