function [Summary_table,Smalles_val] = MF_combine_RULA(Data,ConditionTable_loaded)

Side_name = {'right','left'};
Side_letter = {'R','L'};

%%
clear RelTime RelTime_detail
for ind_trial  = 1:size(Data,2)
    % overall
Gesamt(ind_trial).Final_overall_median = ...
    round(median(Data(ind_trial).rula.final_score.together));
Gesamt(ind_trial).Final_overall_first_quartile = ...
    floor(prctile(Data(ind_trial).rula.final_score.together,25));
Gesamt(ind_trial).Final_overall_third_quartile = ...
    ceil(prctile(Data(ind_trial).rula.final_score.together,75));

RelTime(ind_trial).Final_overall = zeros(1,7);
RelTime(ind_trial).Final_overall(Data(ind_trial).rula.final_score.together_rel(:,1)) = ...
    Data(ind_trial).rula.final_score.together_rel(:,2);

Smalles_val(ind_trial).Final_overall = Data(ind_trial).rula.final_score.together_rel(1,1);
% step 15
Gesamt(ind_trial).Step15_median = ...
    round(median(Data(ind_trial).rula.s15_neck_trunk_leg_score.total));
Gesamt(ind_trial).Step15_first_quartile = ...
    floor(prctile(Data(ind_trial).rula.s15_neck_trunk_leg_score.total,25));
Gesamt(ind_trial).Step15_third_quartile = ...
    ceil(prctile(Data(ind_trial).rula.s15_neck_trunk_leg_score.total,75));

RelTime(ind_trial).Step15 = zeros(1,10);
RelTime(ind_trial).Step15(Data(ind_trial).rula.s15_neck_trunk_leg_score.total_rel(:,1)) = ...
    Data(ind_trial).rula.s15_neck_trunk_leg_score.total_rel(:,2);
Smalles_val(ind_trial).Step15 = Data(ind_trial).rula.s15_neck_trunk_leg_score.total_rel(1,1);

% step 12
Gesamt(ind_trial).Step12_median = ...
    round(median(Data(ind_trial).rula.s12_trunk_neck_leg_post_score.total));
Gesamt(ind_trial).Step12_first_quartile = ...
    floor(prctile(Data(ind_trial).rula.s12_trunk_neck_leg_post_score.total,25));
Gesamt(ind_trial).Step12_third_quartile = ...
    ceil(prctile(Data(ind_trial).rula.s12_trunk_neck_leg_post_score.total,75));

RelTime(ind_trial).Step12 = zeros(1,10);
RelTime(ind_trial).Step12(Data(ind_trial).rula.s12_trunk_neck_leg_post_score.total_rel(:,1)) = ...
    Data(ind_trial).rula.s12_trunk_neck_leg_post_score.total_rel(:,2);
Smalles_val(ind_trial).Step12 = Data(ind_trial).rula.s12_trunk_neck_leg_post_score.total_rel(1,1);

% step 10
Gesamt(ind_trial).Step10_median = ...
    round(median(Data(ind_trial).rula.s10_trunk_pos.total));
Gesamt(ind_trial).Step10_first_quartile = ...
    floor(prctile(Data(ind_trial).rula.s10_trunk_pos.total,25));
Gesamt(ind_trial).Step10_third_quartile = ...
    ceil(prctile(Data(ind_trial).rula.s10_trunk_pos.total,75));

RelTime(ind_trial).Step10 = zeros(1,7);
RelTime(ind_trial).Step10(Data(ind_trial).rula.s10_trunk_pos.total_rel(:,1)) = ...
    Data(ind_trial).rula.s10_trunk_pos.total_rel(:,2);
Smalles_val(ind_trial).Step10 = Data(ind_trial).rula.s10_trunk_pos.total_rel(1,1);

% step 9
Gesamt(ind_trial).Step9_median = ...
    round(median(Data(ind_trial).rula.s9_neck_pos.total));
Gesamt(ind_trial).Step9_first_quartile = ...
    floor(prctile(Data(ind_trial).rula.s9_neck_pos.total,25));
Gesamt(ind_trial).Step9_third_quartile = ...
    ceil(prctile(Data(ind_trial).rula.s9_neck_pos.total,75));

RelTime(ind_trial).Step9 = zeros(1,7);
RelTime(ind_trial).Step9(Data(ind_trial).rula.s9_neck_pos.total_rel(:,1)) = ...
    Data(ind_trial).rula.s9_neck_pos.total_rel(:,2);
Smalles_val(ind_trial).Step9 = Data(ind_trial).rula.s9_neck_pos.total_rel(1,1);


for ind_side = 1:2
% step 8
Gesamt(ind_trial).(['Step8_' Side_letter{ind_side} '_median']) = ...
    round(median(Data(ind_trial).rula.s8_wrist_arm_score.(Side_name{ind_side}).total));
Gesamt(ind_trial).(['Step8_' Side_letter{ind_side} '_first_quartile']) = ...
    floor(prctile(Data(ind_trial).rula.s8_wrist_arm_score.(Side_name{ind_side}).total,25));
Gesamt(ind_trial).(['Step8_' Side_letter{ind_side} '_third_quartile']) = ...
    ceil(prctile(Data(ind_trial).rula.s8_wrist_arm_score.(Side_name{ind_side}).total,75));

RelTime(ind_trial).(['Step8_' Side_letter{ind_side} ]) = zeros(1,10);
RelTime(ind_trial).(['Step8_' Side_letter{ind_side} ])(Data(ind_trial).rula.s8_wrist_arm_score.(Side_name{ind_side}).total_rel(:,1)) = ...
    Data(ind_trial).rula.s8_wrist_arm_score.(Side_name{ind_side}).total_rel(:,2);
Smalles_val(ind_trial).(['Step8_' Side_letter{ind_side} ]) = Data(ind_trial).rula.s8_wrist_arm_score.(Side_name{ind_side}).total_rel(1,1);

% step 5
Gesamt(ind_trial).(['Step5_' Side_letter{ind_side} '_median']) = ...
    round(median(Data(ind_trial).rula.s5_arm_post_score.(Side_name{ind_side}).total));
Gesamt(ind_trial).(['Step5_' Side_letter{ind_side} '_first_quartile']) = ...
    floor(prctile(Data(ind_trial).rula.s5_arm_post_score.(Side_name{ind_side}).total,25));
Gesamt(ind_trial).(['Step5_' Side_letter{ind_side} '_third_quartile']) = ...
    ceil(prctile(Data(ind_trial).rula.s5_arm_post_score.(Side_name{ind_side}).total,75));

RelTime(ind_trial).(['Step5_' Side_letter{ind_side} ]) = zeros(1,10);
RelTime(ind_trial).(['Step5_' Side_letter{ind_side} ])(Data(ind_trial).rula.s5_arm_post_score.(Side_name{ind_side}).total_rel(:,1)) = ...
    Data(ind_trial).rula.s5_arm_post_score.(Side_name{ind_side}).total_rel(:,2);
Smalles_val(ind_trial).(['Step5_' Side_letter{ind_side} ]) = Data(ind_trial).rula.s5_arm_post_score.(Side_name{ind_side}).total_rel(1,1);

% step 4
Gesamt(ind_trial).(['Step3and4_' Side_letter{ind_side} '_median']) = ...
    round(median(Data(ind_trial).rula.s4_wrist_pos.(Side_name{ind_side}).total));
Gesamt(ind_trial).(['Step3and4_' Side_letter{ind_side} '_first_quartile']) = ...
    floor(prctile(Data(ind_trial).rula.s4_wrist_pos.(Side_name{ind_side}).total,25));
Gesamt(ind_trial).(['Step3and4_' Side_letter{ind_side} '_third_quartile']) = ...
    ceil(prctile(Data(ind_trial).rula.s4_wrist_pos.(Side_name{ind_side}).total,75));

RelTime(ind_trial).(['Step3and4_' Side_letter{ind_side} ]) = zeros(1,7);
RelTime(ind_trial).(['Step3and4_' Side_letter{ind_side} ])...
    (Data(ind_trial).rula.s4_wrist_pos.(Side_name{ind_side}).total_rel(:,1)) = ...
    Data(ind_trial).rula.s4_wrist_pos.(Side_name{ind_side}).total_rel(:,2);
Smalles_val(ind_trial).(['Step3and4_' Side_letter{ind_side} ]) = Data(ind_trial).rula.s4_wrist_pos.(Side_name{ind_side}).total_rel(1,1);

% step 2
Gesamt(ind_trial).(['Step2_' Side_letter{ind_side} '_median']) = ...
    round(median(Data(ind_trial).rula.s2_lower_arm_pos.(Side_name{ind_side}).total));
Gesamt(ind_trial).(['Step2_' Side_letter{ind_side} '_first_quartile']) = ...
    floor(prctile(Data(ind_trial).rula.s2_lower_arm_pos.(Side_name{ind_side}).total,25));
Gesamt(ind_trial).(['Step2_' Side_letter{ind_side} '_third_quartile']) = ...
    ceil(prctile(Data(ind_trial).rula.s2_lower_arm_pos.(Side_name{ind_side}).total,75));

RelTime(ind_trial).(['Step2_' Side_letter{ind_side} ]) = zeros(1,3);
RelTime(ind_trial).(['Step2_' Side_letter{ind_side} ])(Data(ind_trial).rula.s2_lower_arm_pos.(Side_name{ind_side}).total_rel(:,1)) = ...
    Data(ind_trial).rula.s2_lower_arm_pos.(Side_name{ind_side}).total_rel(:,2);
Smalles_val(ind_trial).(['Step2_' Side_letter{ind_side} ]) = Data(ind_trial).rula.s2_lower_arm_pos.(Side_name{ind_side}).total_rel(1,1);

% step 1
Gesamt(ind_trial).(['Step1_' Side_letter{ind_side} '_median']) = ...
    round(median(Data(ind_trial).rula.s1_upper_arm_pos.(Side_name{ind_side}).total));
Gesamt(ind_trial).(['Step1_' Side_letter{ind_side} '_first_quartile']) = ...
    floor(prctile(Data(ind_trial).rula.s1_upper_arm_pos.(Side_name{ind_side}).total,25));
Gesamt(ind_trial).(['Step1_' Side_letter{ind_side} '_third_quartile']) = ...
    ceil(prctile(Data(ind_trial).rula.s1_upper_arm_pos.(Side_name{ind_side}).total,75));

RelTime(ind_trial).(['Step1_' Side_letter{ind_side} ]) = zeros(1,7);
RelTime(ind_trial).(['Step1_' Side_letter{ind_side} ])(Data(ind_trial).rula.s1_upper_arm_pos.(Side_name{ind_side}).total_rel(:,1)) = ...
    Data(ind_trial).rula.s1_upper_arm_pos.(Side_name{ind_side}).total_rel(:,2);
Smalles_val(ind_trial).(['Step1_' Side_letter{ind_side} ]) = Data(ind_trial).rula.s1_upper_arm_pos.(Side_name{ind_side}).total_rel(1,1);

end


if rem(ind_trial,100)==0
    disp([num2str(ind_trial/size(Data,2)*100,'% 2.1f') '% done'])
end
end

Summary_table = [ConditionTable_loaded(:,{'SubjectID','Condition1','Condition2','Condition3','Condition4','Condition5'})...
    struct2table(Gesamt) ...
    struct2table(RelTime)];

Summary_table.Properties.VariableNames(2:6) = [{'Teamfunktion'} {'Konzept'}...
    {'Fachrichtung'} {'Quadrant'} {'Aufgabe'}];


