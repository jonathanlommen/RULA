function  [ConditionTable_loaded,Data,Settings] = MF_02SelectAndRULA_v01(PathName,Condition_db,ConditionTable,Subject_db)
%%
if exist([PathName '\Project_data_v01.mat'],'file')==2
    Answer = questdlg('recalculate data?','Abk�rzung2','Yes','No','No');
else
    Answer  = 'Yes';
end
%%
if strcmp(Answer,'Yes')

clear Subject Data
for ind_c = 1:size(Condition_db,2)
    [Sel_cond_list{ind_c}] = unique(ConditionTable.(['Condition' num2str(ind_c)]));
    
    % if you want to select the condition, please comment the following line 
%     and uncomment the line after.
    Sel_cond{ind_c} = 1:size(Sel_cond_list{ind_c},1);
%     [Sel_cond{ind_c}] = listdlg('ListString',unique(ConditionTable.(['Condition' num2str(ind_c)])));
    
end

% Condition = inputdlg({'Enter the condition'});
ConditionTable_loaded = ConditionTable;
for ind_c = 1:size(Condition_db,2)
    ConditionTable_loaded = ConditionTable_loaded(ismember(...
        ConditionTable_loaded.(['Condition' num2str(ind_c)]),...
        Sel_cond_list{ind_c}(Sel_cond{ind_c})),:);
end
    Flag.run = 1;

if ~exist([PathName '\RULA_tables\'],'dir')==7
    mkdir(PathName,'\RULA_tables')
    disp('rula Tabellen m�ssen noch in den Ordner RULA_tables')
end
Settings.PathCond = [PathName '\RULA_tables'];
if exist([PathName '\RULA_tables\Wrist and Arm Posture Score.xlsx'],'file')==2
    Settings.RULA.TableA = readtable([PathName '\RULA_tables\Wrist and Arm Posture Score.xlsx'],'Range','C4:J22');
else
    disp('Keine Tabelle A')
    Flag.run = 0;
end
if exist([PathName '\RULA_tables\Trunk Posture Score.xlsx'],'file')==2
    Settings.RULA.TableB = readtable([PathName '\RULA_tables\Trunk Posture Score.xlsx'],'Range','B4:M10');
else
    disp('Keine Tabelle B')
    Flag.run = 0;
end
if exist([PathName '\RULA_tables\Table C.xlsx'],'file')==2
    Settings.RULA.TableC = readtable([PathName '\RULA_tables\Table C.xlsx'],'Range','B2:H10');
else
    disp('Keine Tabelle C')
    Flag.run = 0;
end

Settings.PathName = PathName;
Settings.Used_variables= {'time';'orientation';'position';'jointAngle';'centerOfMass'};
%%
if Flag.run
for ind_trial = 1:size(ConditionTable_loaded,1)
    %%
    if isempty(ConditionTable_loaded.RULA{ind_trial})
        ConditionTable_loaded.RULA{ind_trial} = {'not done'};
    end
    if ~strcmp(ConditionTable_loaded.RULA{ind_trial},'done')
    disp(['load trial .... ' ConditionTable_loaded.Filename{ind_trial}])
    Tmp = load(fullfile(ConditionTable_loaded.PathName{ind_trial},...
        ConditionTable_loaded.Filename{ind_trial}));
    Fields = fieldnames(Tmp.Subject);
    for ind_s = 1:size(Fields,1)
        Subject_tmp.(Fields{ind_s}) = Tmp.Subject.(Fields{ind_s});
    end
    Subject_tmp.Gender = Subject_db.Sex(ismember(Subject_db.SubjectID,ConditionTable_loaded.SubjectID(ind_trial)));

    if ind_trial == 1
        Settings.JointNames = {Subject_tmp.jointData(:).label}';
        Settings.SegmentNames = {Subject_tmp.segmentData(:).label}';
        Settings.Dimensionsjoint = {'abduction','rotation','flexion'}';
        Settings.Dimensionssegment = {'x','y','z'};
    end
    
    %%
    try
    Datafields = fieldnames(Subject_tmp.Data);
    for ind_fields = 1:size(Datafields,1)
        if sum(ismember(Settings.Used_variables,Datafields{ind_fields}))>0
        Data_tmp.(Datafields{ind_fields}) = ...
            cell2mat({Subject_tmp.Data().(Datafields{ind_fields})}'); %#ok<*SAGROW>
        end
    end
    catch ME
        disp(getReport(ME))
    end  
    if isfield(Data_tmp,'jointAngle')
        Data_tmp.v_jointAngle = diff(Data_tmp.jointAngle)/(mean(diff(Data_tmp.time))*1e-3);
    end
    %%
    RULA_calc_scores;
    rula = RULA_calc_scores_rel(rula);
    
    
    Data(ind_trial).rula = rula;
    Data(ind_trial).Parameter = Subject_tmp.Parameter;
%     Data(ind_trial).Data_tmp = Data_tmp;
    if ~exist([PathName '\04_Processed'],'dir')
        mkdir([PathName '\04_Processed'])
    end
    save(fullfile([PathName '\04_Processed\'],[ConditionTable_loaded.Filename{ind_trial}(1:end-4) '_processed.mat']),...
        'rula','Data_tmp','Subject_tmp')
    ConditionTable.RULA(ismember(ConditionTable.Filename,ConditionTable_loaded.Filename{ind_trial})) = {'done'};
    ConditionTable_loaded.RULA(ismember(ConditionTable_loaded.Filename,ConditionTable_loaded.Filename{ind_trial})) = {'done'};
    disp([num2str(ind_trial/size(ConditionTable_loaded,1)*100) '% loaded'])
else
    load(fullfile([PathName '\04_Processed\'],[ConditionTable_loaded.Filename{ind_trial}(1:end-4) '_processed.mat']),...
        'rula','Subject_tmp')
    Data(ind_trial).rula = rula;
    Data(ind_trial).Parameter = Subject_tmp.Parameter;
%     Data(ind_trial).Data_tmp = Data_tmp;
    ConditionTable.RULA(ismember(ConditionTable.Filename,ConditionTable_loaded.Filename{ind_trial})) = {'done'};
    ConditionTable_loaded.RULA(ismember(ConditionTable_loaded.Filename,ConditionTable_loaded.Filename{ind_trial})) = {'done'};
    disp([num2str(ind_trial/size(ConditionTable_loaded,1)*100) '% loaded'])
end
end
    Files_done = ConditionTable(:,{'Filename','RULA'});
    writetable(Files_done,'Dentist_db.xlsx','Sheet','Filedb');
    save([PathName '\Project_table.mat'],'ConditionTable','Subject_db','Condition_db')
    Screensize = get(0,'ScreenSize');
    Flag.print = 1;
    save([PathName '\Project_data_v01.mat'],'ConditionTable_loaded','Data','Settings','-v7.3')
end
else
    load([PathName '\Project_data_v01.mat'],'ConditionTable_loaded','Data','Settings')
end
