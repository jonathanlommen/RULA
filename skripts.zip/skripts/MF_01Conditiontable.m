function [ConditionTable,Subject_db,Condition_db] = MF_01Conditiontable_v02(PathName,PathNameMAT)
if exist([PathName '\Project_table.mat'],'file')==2
    Answer = questdlg('Reload project database?','Quick Choice 1','Yes','No','No');
else
    Answer  = 'Yes';
end
% convert MVNX files to mat files. Not required here but for consitency
% left in. (mvnx is the file format of xsense.
if strcmp(Answer,'Yes')
    MVNX_files= dir([PathName '\01_rawData\*.mvnx']);
    %%
    if ~isempty(MVNX_files)
        Answer = questdlg('New MVNX files found. Convert them now?',...
            'Convert Data','Yes','No','No');
        if strcmp(Answer,'Yes')
            if exist([PathName '\01_rawDataconverted'],'dir')==0
                mkdir([PathName '\01_rawDataconverted'])
            end
            if exist(PathNameMAT,'dir')==0
                mkdir(PathNameMAT)
            end
            PathOut = [PathNameMAT];

            %%
            if ~isempty(MVNX_files)
                for ind_f = 1:size(MVNX_files,1)
                Subject = MF_readMVNX(MVNX_files(ind_f).folder,MVNX_files(ind_f).name);
                save(fullfile(PathOut,[Subject.FileData.filename(1:end-4) 'mat']),'Subject');
                movefile(fullfile(MVNX_files(ind_f).folder,MVNX_files(ind_f).name),fullfile([PathName '\01_rawDataconverted'],MVNX_files(ind_f).name))
                disp([num2str(ind_f/size(MVNX_files,1)*100) '% done'])
                end
            end

        end
    end
    Filenames = dir([PathNameMAT '\*.mat']);
    if exist([PathName '\Dentist_db.xlsx'],'file')
    Subject_db = readtable([PathName '\Dentist_db.xlsx'],'Sheet','Stammdaten');
    Condition_db = readtable([PathName '\Dentist_db.xlsx'],'Sheet','Condition');
    File_db = readtable([PathName '\Dentist_db.xlsx'],'Sheet','Filedb');
    Flag.run = 1;
    else
        disp('Please insert a file called Dentist_db.xlsx into the project root directory')
        Flag.run = 0;
    end
%     update File in excel
%     File_db.Schrittzyklus(~ismember(({Filenames(:).name}'),File_db.Filename{:}))
%     
%     writetable
    if Flag.run
    f = waitbar(0,'processing data ...');
    for ind_f = 1:size(Filenames,1)
        %%
        load(fullfile(PathNameMAT,Filenames(ind_f).name));
        ConditionTable(ind_f).SubjectID = Filenames(ind_f).name(14:18);
        for ind_c = 1:size(Condition_db,2)
                switch ind_c
                    case 1
                        if str2num(Filenames(ind_f).name(14)) == 1
                            ConditionTable(ind_f).(['Condition' num2str(ind_c)]) = {'ZA'};
                        else
                            ConditionTable(ind_f).(['Condition' num2str(ind_c)]) = {'ZFA'};
                        end                            
                    case 2
                        ConditionTable(ind_f).(['Condition' num2str(ind_c)]) = Filenames(ind_f).name(1:2);
                    case 3
                        switch Filenames(ind_f).name(16)
                            case 'C'
            ConditionTable(ind_f).(['Condition' num2str(ind_c)]) = 'Chir';
                        end
                    case 4
                        ConditionTable(ind_f).(['Condition' num2str(ind_c)]) = Filenames(ind_f).name(4:5);
                    case 5
                        ConditionTable(ind_f).(['Condition' num2str(ind_c)]) = Filenames(ind_f).name(7:8);
                end
        end
        ConditionTable(ind_f).Filename = Filenames(ind_f).name;
        ConditionTable(ind_f).PathName = [PathNameMAT '\'];
        ConditionTable(ind_f).RULA = File_db.RULA(ismember(File_db.Filename,Filenames(ind_f).name));
        waitbar(rem(ind_f,10)/10,f);
        if rem(size(Filenames,1),50)==0
            disp(1/size(Filenames,1))
        end
    end
    close(f);
    pause(.01)

%     ConditionTable = struct2table(ConditionTable);
    ConditionTable = struct2table(ConditionTable,'AsArray',1);
    
%     ConditionTable.Condition1(ismember(ConditionTable.Filename,'Fabi_1-011.mat'))= {'Kaercher'};
    save([PathName '\Project_table.mat'],'ConditionTable','Subject_db','Condition_db')
    end
else
    load([PathName '\Project_table.mat'],'ConditionTable','Subject_db','Condition_db')
    if exist('PathNameMAT','var')
        if ~strcmp(ConditionTable.PathName{1},PathNameMAT)
            ConditionTable.PathName(:) = {PathNameMAT};
        end
    end
end

