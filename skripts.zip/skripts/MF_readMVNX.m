function Output = MF_readMVNX(PathName,FileName)

tree = load_mvnx(fullfile(PathName,FileName));
%%
% xsense specific Data
Output.xsense.xmlns_xsi = tree.xmlns_xsi;
Output.xsense.xsi_schemaLocation = tree.xsi_schemaLocation;
Output.xsense.version = tree.version;
Output.xsense.mvn = tree.mvn;
Output.xsense.securityCode = tree.securityCode;

% File specific Data
Output.FileData.filename = FileName;
Output.FileData.pathname = PathName;
Output.FileData.originalFilename = tree.subject.originalFilename;
Output.FileData.recDate = tree.subject.recDate;
Output.FileData.label = tree.subject.label;
Output.FileData.torsoColor = tree.subject.torsoColor;
if isfield(tree.subject,'comment')
    Output.FileData.comment = tree.subject.comment;
else
    Output.FileData.comment = {''};
end    


Output.Parameter.frameRate = tree.subject.frameRate;
Output.Parameter.segmentCount = tree.subject.segmentCount;

%retrieve sensor labels
%creates a struct with sensor data
if isfield(tree.subject,'sensors') && isstruct(tree.subject.sensors)
    Output.sensorData = tree.subject.sensors.sensor;
end
%retrieve segment labels
%creates a struct with segment definitions
if isfield(tree.subject,'segments') && isstruct(tree.subject.segments)
    Output.segmentData = tree.subject.segments.segment;
end
%retrieve joint labels
%creates a struct with joint definitions
if isfield(tree.subject,'joints') && isstruct(tree.subject.joints)
    Output.jointData = tree.subject.joints.joint;
end
% retrieve identity
if isfield(tree.subject.frames.frame(1),'type') && ...
        sum(ismember({tree.subject.frames.frame(:).type},'identity'))
    Output.Identity.orientation = ...
        tree.subject.frames.frame(ismember({tree.subject.frames.frame(:).type},'identity')).orientation;
    Output.Identity.position = ...
        tree.subject.frames.frame(ismember({tree.subject.frames.frame(:).type},'identity')).position;
end    
% retrieve tpose
if isfield(tree.subject.frames.frame(1),'type') && ...
        sum(ismember({tree.subject.frames.frame(:).type},'tpose'))
    Output.Identity.orientation = ...
        tree.subject.frames.frame(ismember({tree.subject.frames.frame(:).type},'tpose')).orientation;
    Output.Identity.position = ...
        tree.subject.frames.frame(ismember({tree.subject.frames.frame(:).type},'tpose')).position;
end    
% retrieve tpose-isb
if isfield(tree.subject.frames.frame(1),'type') && ...
        sum(ismember({tree.subject.frames.frame(:).type},'tpose-isb'))
    Output.Identity.orientation = ...
        tree.subject.frames.frame(ismember({tree.subject.frames.frame(:).type},'tpose-isb')).orientation;
    Output.Identity.position = ...
        tree.subject.frames.frame(ismember({tree.subject.frames.frame(:).type},'tpose-isb')).position;
end    

% retrieve actual Data
if isfield(tree.subject.frames.frame(1),'type') && ...
        sum(ismember({tree.subject.frames.frame(:).type},'normal'))
    Output.Data = ...
        tree.subject.frames.frame(ismember({tree.subject.frames.frame(:).type},'normal'));
    if sum(diff(cell2mat({Output.Data(:).time}))<0)
        first_neg = find(diff(cell2mat({Output.Data(:).time}))<0);
        Output.Data = Output.Data(1:first_neg(1));
    end
    
end    
end


function mvnx = load_mvnx(filename)
% mvnx = load_mvnx(filename)
% loads a mvnx file
% filename is name of file (including path)
% mvnx is result struct containing all data of the mvnx file
% Xsens Technologies BV 28-05-2015

%% check filename
if isempty(strfind(filename,'mvnx'))
    filename = [filename '.mvnx'];
end
if ~exist(filename,'file')
    error([mfilename ':xsens:filename'],['No file with filename: ' filename ', file is not present or file has wrong format (function only reads .mvnx)'])
end
%% read data
fid = fopen(filename, 'r', 'n', 'UTF-8');
content = char(fread(fid,'char')');
fclose(fid);
%% get data into a cell array, one cell per line
lines = find(content == 10);
cellContent = cell(1,length(lines));

hWaitbar = waitbar(0, 'MVNX import: importing data...');
for n=1:length(lines)
    if n==1
        cellContent{n} = content(1:lines(n)-1);
    else
        cellContent{n} = content(lines(n-1)+1:lines(n)-1);
    end
end
% look for comment lines and remove them
% if 
cellContent(cellfun(@(x) x(1)=='-' || (x(1)=='<' && (x(2)=='?' || x(2)=='!')),cellContent)) = [];

% get start of text and clean up some
index = cellfun(@(x) find(x==60,1),cellContent);
openandclose = cellfun(@(x) sum(x==60)==2,cellContent); % lines with have an opening and closing statement in one line
hasOpeningTag = cellfun(@(x) ~isempty(find(x==60,1)), cellContent);
index = index(hasOpeningTag);
openandclose = openandclose(hasOpeningTag);
cellContent = cellContent(hasOpeningTag);
cellContent = cellfun(@(x) x(find(x==60,1):end), cellContent,'UniformOutput',false);

%% get start and end words
n = 0;clear value name
iWord = 0;
word = cell(1,length(cellContent));
wordindex = cell(1,length(cellContent));
wordvalue = cell(1,length(cellContent));
wordfields = cell(1,length(cellContent));
while n < length(cellContent)
    n=n+1;
    line = cellContent{n};oneword = false;
    hooks = find(line == 62);
    iWord = iWord+1;
    wordindex{iWord} = index(n);
    if any(line == 32) && ~openandclose(n)
        if ~isempty(hooks) && hooks(1) < find(line==32,1)
            word{iWord} = line(2:hooks(1)-1);
            iLine = hooks(1)+1;
        else
            word{iWord} = line(2:find(line==32,1)-1);
            iLine = find(line==32,1)+1;
        end
    elseif ~isempty(hooks) && length(line)>=8 && strcmp('comment',line(2:8))
        % add exception for comment
        word{iWord} = line(2:hooks(1)-1);
        iLine = hooks(1)+1;
    elseif openandclose(n)
        word{iWord} = line(2:find(line==62,1)-1);
        iLine = find(line==62,1)+1;
    else
        word{iWord} = line(2:end-1);
        oneword = true;
    end
    if word{iWord}(1) ~= '/'
        if ~oneword && ~openandclose(n)
            k = find(line == 34);
            k = reshape(k,2,length(k)/2)';
            l = [iLine find(line(iLine:end) == 61)+iLine-2];
            fieldname = cell(1,length(l)-1); value = cell(1,length(l)-1);
            if ~isempty(k)
                for il=1:size(k,1)
                    fieldname{il} = line(iLine:find(line(iLine:end) == 61,1)+iLine-2);
                    if size(k,1) > 1 && il < size(k,1)
                        a = strfind(line(iLine:end),'" ')+iLine+1;
                        iLine = a(1);
                    end
                    value{il} = line(k(il,1)+1:k(il,2)-1);
                end
            else
                value = []; fieldname =[];
                value = line(find(line == 62,1)+1:end);
            end
        elseif ~oneword && openandclose(n)
            value = []; fieldname =[];
            value = line(find(line == 62,1)+1:find(line==60,1,'last')-1);
        else
            value = NaN;fieldname = [];
        end
        wordvalue{iWord} = value;
        wordfields{iWord} = fieldname;
    end
end
isendword = cellfun(@(x) x(1) == '/',word);
endwords = cellfun(@(x) x(2:end),word(isendword),'UniformOutput',false);
kindofendwords = unique(endwords);
placeoffirststartword = zeros(1,length(kindofendwords));
placeofallendwords = cell(1,length(kindofendwords));
placeofallstartwords = cell(1,length(kindofendwords));
for n=1:length(kindofendwords)
    lengthWord = length(cell2mat(kindofendwords(n)));
    placeoffirststartword(n) = find(strncmp(word,kindofendwords(n),lengthWord),1);
    placeofallstartwords{n} = find(strncmp(word,kindofendwords(n),lengthWord));
    placeofallendwords{n} = find(strncmp(word,['/' kindofendwords{n}],lengthWord+1));
end
[a b] = sort(placeoffirststartword);
startwords = kindofendwords(b);
for n=1:length(startwords)
    obj.(startwords{n}).number = length(placeofallstartwords{n});
    obj.(startwords{n}).index = index(a(n));
    obj.(startwords{n}).count = 0;
end

%% get values
for n=1:length(wordvalue)
    if mod(n,5000) == 0
        waitbar((n/length(wordvalue))/2, hWaitbar);
    end
    
    if iscell(wordvalue{n})
        if length(wordvalue{n}) == 1
            numericValue = tryParseNumeric(wordvalue{n}{1});
            if ~isempty(numericValue)
                wordvalue{n} = numericValue;
            else
                wordvalue{n} = wordvalue{n}{1};
            end
        else
            for m=1:length(wordvalue{n})
                numericValue = tryParseNumeric(wordvalue{n}{m});
                if ~isempty(numericValue)
                    wordvalue{n}{m} = numericValue;
                end
            end
        end
    else
        numericValue = tryParseNumeric(wordvalue{n});
        if ~isempty(numericValue)
            wordvalue{n} = numericValue;
        end
    end
end
%% put everything in struct
firstFramesFound = false;
nFramesToBeFound = 5;
nFramesFound = 0;
nFrames = length(cell2mat(placeofallendwords(strcmp(kindofendwords,'frame'))));
lastwordisendword = false;lastendword = '';
superstruct = struct;name = cell(1,max(index)+1);namecounter = ones(1,max(index));endplace = inf(1,max(index));
%%
for iWord=1:length(word)
    if mod(iWord,5000) == 0
        waitbar(iWord/length(word) + 0.5, hWaitbar);
    end
    if word{iWord}(1)=='/'
        startword = word{iWord}(2:end);
        if any(strcmp(startword,name))
            name(find(strcmp(startword,name),1):end) = [];
        end
        if lastwordisendword
            obj.(lastendword).count = 0;
        end
        lastendword = startword;
        lastwordisendword = true;
    else
        lastwordisendword = false;
        try
            if ~isempty(wordfields{iWord})
                wordfields{iWord} = cellfun(@(x) x(x~=32), wordfields{iWord},'UniformOutput',false);
            end
            word(iWord) = checkText(word(iWord));
            wordfields{iWord} = checkText(wordfields{iWord});
            
            if any(strncmp(startwords,word{iWord},length(startwords)))
                if ~isfield(obj, word{iWord})
                    obj.(word{iWord}).number = 0;
                    obj.(word{iWord}).index = index(iWord);
                    obj.(word{iWord}).count = 0;
                end
                if strcmp(word{iWord},'frame')
                    nFramesFound = nFramesFound + 1;
                    if ~firstFramesFound && nFramesFound >= nFramesToBeFound
                        firstFramesFound = true;
                        % preallocate frames in superstruct
                        % Assume remainder of the file contains frames,
                        % with exception of security code at the end
                        frames(1:nFrames,1) = superstruct.mvnx.subject.frames.frame(end);
                        frames(1:nFramesFound-1) = superstruct.mvnx.subject.frames.frame(1:nFramesFound-1);
                    end
                    if firstFramesFound
                        fields = wordfields{iWord};
                        for il = 1:length(fields)
                            frames(nFramesFound).(fields{il}) = wordvalue{iWord}{il};
                        end
                    end
                end
                obj.(word{iWord}).count = obj.(word{iWord}).count +1;
                name{index(iWord)} = word{iWord};
                namecounter(index(iWord)) = obj.(word{iWord}).count;
                if ~firstFramesFound && (iscell(wordvalue{iWord}) || ~isempty(wordvalue{iWord}) && all(~isnan(wordvalue{iWord})))
                    superstruct = setvalue(superstruct,index(iWord),wordvalue{iWord},name(1:index(iWord)),wordfields{iWord},namecounter);
                end
            elseif iWord > 1 && strcmp(word{iWord},word{iWord-1})
                name{index(iWord)} = word{iWord};
                namecounter(index(iWord)) = namecounter(index(iWord))+1;
                superstruct = setvalue(superstruct,index(iWord),wordvalue{iWord},name(1:index(iWord)),wordfields{iWord},namecounter);
            else
                name{index(iWord)} = word{iWord};
                namecounter(index(iWord)) = 1;
                if firstFramesFound && ~strcmp(word{iWord},'securityCode')
                    frames(nFramesFound).(word{iWord}) = wordvalue{iWord};
                else
                    superstruct = setvalue(superstruct,index(iWord),wordvalue{iWord},name(1:index(iWord)),wordfields{iWord},namecounter);
                end
            end
        catch e
            disp(getReport(e))
        end
    end
end
if firstFramesFound
    superstruct.mvnx.subject.frames.frame = frames';
    if obj.mvnx.number > nFramesFound
        superstruct.mvnx.subject.frames.frame(nFramesFound+1:end) = [];
    end
end

%% get output
mvnx = superstruct.mvnx;

delete(hWaitbar);
end
function numericValue = tryParseNumeric(value)
numericValue = [];
if isstring(value)
    value = char(value);
end
if ~(ischar(value) || isnumeric(value))
    return;
end
if isnumeric(value)
    numericValue = value;
    return;
end
if isempty(value) || contains(value, ':')
    return;
end
numericValue = str2num(value); %#ok<ST2NM>
if isempty(numericValue)
    numericValue = [];
end
end
function superstruct = setvalue(superstruct,index,value,name,fields,namecounter)
%superstruct = setvalue(superstruct,index,value,name,fields,namecounter)
% add values to a very big struct
if ~isempty(fields) && (~iscell(fields) || ~isempty(fields{1}))
    if length(fields) == 1
        name(end+1) = fields;
    else
        name{end+1} = fields;
    end
    index = index+1;
end
switch index
    case 1
        if ~iscell(name{1})
            superstruct.(name{1}) = value;
        else
            for il = 1:length(name{1})
                superstruct.(name{1}{il}) = value{il};
            end
        end
    case 2
        if ~iscell(name{2})
            superstruct.(name{1})(namecounter(1)).(name{2}) = value;
        else
            for il = 1:length(name{2})
                superstruct.(name{1})(namecounter(1)).(name{2}{il}) = value{il};
            end
        end
    case 3
        if ~iscell(name{3})
            superstruct.(name{1})(namecounter(1)).(name{2})(namecounter(2)).(name{3})...
                = value;
        else
            for il = 1:length(name{3})
                superstruct.(name{1})(namecounter(1)).(name{2})(namecounter(2)).(name{3}{il}) = value{il};
            end
        end
    case 4
        if ~iscell(name{4})
            superstruct.(name{1})(namecounter(1)).(name{2})(namecounter(2)).(name{3})(namecounter(3))....
                .(name{4}) = value;
        else
            for il = 1:length(name{4})
                superstruct.(name{1})(namecounter(1)).(name{2})(namecounter(2)).(name{3})(namecounter(3))...
                    .(name{4}{il}) = value{il};
            end
        end
    case 5
        if ~iscell(name{5})
            superstruct.(name{1})(namecounter(1)).(name{2})(namecounter(2)).(name{3})(namecounter(3))....
                .(name{4})(namecounter(4)).(name{5}) = value;
        else
            for il = 1:length(name{5})
                superstruct.(name{1})(namecounter(1)).(name{2})(namecounter(2)).(name{3})(namecounter(3))....
                    .(name{4})(namecounter(4)).(name{5}{il}) = value{il};
            end
        end
    case 6
        if ~iscell(name{6})
            superstruct.(name{1})(namecounter(1)).(name{2})(namecounter(2)).(name{3})(namecounter(3))....
                .(name{4})(namecounter(4)).(name{5})(namecounter(5)).(name{6}) = value;
        else
            for il = 1:length(name{6})
                superstruct.(name{1})(namecounter(1)).(name{2})(namecounter(2)).(name{3})(namecounter(3))....
                    .(name{4})(namecounter(4)).(name{5})(namecounter(5)).(name{6}{il}) = value{il};
            end
        end
    case 7
        if ~iscell(name{7})
            superstruct.(name{1})(namecounter(1)).(name{2})(namecounter(2)).(name{3})(namecounter(3))....
                .(name{4})(namecounter(4)).(name{5})(namecounter(5)).(name{6})(namecounter(6))...
                .(name{7}) = value;
        else
            for il = 1:length(name{7})
                superstruct.(name{1})(namecounter(1)).(name{2})(namecounter(2)).(name{3})(namecounter(3))....
                    .(name{4})(namecounter(4)).(name{5})(namecounter(5)).(name{6})(namecounter(6))...
                    .(name{7}{il}) = value{il};
            end
        end
    case 8
        if ~iscell(name{8})
            superstruct.(name{1})(namecounter(1)).(name{2})(namecounter(2)).(name{3})(namecounter(3))....
                .(name{4})(namecounter(4)).(name{5})(namecounter(5)).(name{6})(namecounter(6))...
                .(name{7})(namecounter(7)).(name{8}) = value;
        else
            for il = 1:length(name{7})
                superstruct.(name{1})(namecounter(1)).(name{2})(namecounter(2)).(name{3})(namecounter(3))....
                    .(name{4})(namecounter(4)).(name{5})(namecounter(5)).(name{6})(namecounter(6))...
                    .(name{7})(namecounter(7)).(name{8}{il}) = value{il};
            end
        end
end
end

function word = checkText(word)
%word = checkText(word)
% make sure the field name is just text and allowed symbols.
if ~isempty(word)
    if ~iscell(word)
        error('should get cells')
    end
    for i=1:length(word)
        if length(word{i})>1
            word{i}(word{i}=='!') = [];
            word{i}(word{i}==':') = '_';
            if word{i}(end) == '/'
                word{i}(end) = [];
            end
            while (word{i}(1) < 65 || word{i}(1) > 122 || (word{i}(1)> 90 && word{i}(1) < 97))
                word{i}(1)=[];
            end
        end
    end
end
end
