function [Angle_int,Angles,spm_results,Stats] = MF_combine_RULA_hist(Data,ConditionTable_loaded)
%%
fieldnames_body = {'s1_upper_arm_pos_hist','s2_lower_arm_pos_hist',...
    's3_wrist_pos_hist','s4_wrist_pos_hist'}';
fieldnames_body1 = {'s9_neck_pos_hist','s10_trunk_pos_hist'}';
Side_name = {'right','left'};

clear Angles Angle_int
for ind_trial = 1:size(Data,2)
    for ind_side =1:2
for ind_body = 1:size(fieldnames_body,1)
    fieldn_dir = fieldnames(Data(1).rula.(fieldnames_body{ind_body}).(Side_name{ind_side}).part);
    for ind_dir = 1:size(fieldn_dir,1)
        Angles.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir})(ind_trial,:) = ...
            [Data(ind_trial).rula.(fieldnames_body{ind_body}).(Side_name{ind_side}).part.(fieldn_dir{ind_dir}).edges([1 end]) ...
            diff(Data(ind_trial).rula.(fieldnames_body{ind_body}).(Side_name{ind_side}).part.(fieldn_dir{ind_dir}).edges([1 2]))];
    end
end
    end
for ind_body = 1:size(fieldnames_body1,1)
    fieldn_dir = fieldnames(Data(1).rula.(fieldnames_body1{ind_body}).part);
    for ind_dir = 1:size(fieldn_dir,1)
        Angles.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir})(ind_trial,:) = ...
            [Data(ind_trial).rula.(fieldnames_body1{ind_body}).part.(fieldn_dir{ind_dir}).edges([1 end]) ...
            diff(Data(ind_trial).rula.(fieldnames_body1{ind_body}).part.(fieldn_dir{ind_dir}).edges([1 2]))];
    end
end    
    
    
    
end


%%
for ind_body = 1:size(fieldnames_body,1)
    fieldn_dir = fieldnames(Data(1).rula.(fieldnames_body{ind_body}).(Side_name{ind_side}).part);
    for ind_side = 1:2
    for ind_dir = 1:size(fieldn_dir,1)
        for ind_trial = 1:size(Data,2)
            Angle_min = min(Angles.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir})(:,1));
            Angle_max = max(Angles.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir})(:,2));
            Diff = Angles.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir})(1,3);
            if size(Data(ind_trial).rula.(fieldnames_body{ind_body}).(Side_name{ind_side}).part.(fieldn_dir{ind_dir}).N,2) == 1
                [~,loc] = (min(abs((floor(Angle_min):Diff:ceil(Angle_max))-...
                    (Data(ind_trial).rula.(fieldnames_body{ind_body}).(Side_name{ind_side}).part.(fieldn_dir{ind_dir}).edges(1)+Diff/2))));
                Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).rel_N(ind_trial,:) = NaN;
                Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).rel_N(ind_trial,loc) = 1;
            else
                N_count = Data(ind_trial).rula.(fieldnames_body{ind_body}).(Side_name{ind_side}).part.(fieldn_dir{ind_dir}).N;
                N_count = smooth(N_count,5);
            Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).rel_N(ind_trial,:) = interp1(...
                Data(ind_trial).rula.(fieldnames_body{ind_body}).(Side_name{ind_side}).part.(fieldn_dir{ind_dir}).edges(1:(end-1)) + Diff/2,...
                N_count/sum(N_count),floor(Angle_min):Diff:ceil(Angle_max));
            Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).Angle(ind_trial,:) = ...
                floor(Angle_min):Diff:ceil(Angle_max);
            end
        end
    end
    end
end
%%
for ind_body = 1:size(fieldnames_body1,1)
    fieldn_dir = fieldnames(Data(1).rula.(fieldnames_body1{ind_body}).part);
    for ind_dir = 1:size(fieldn_dir,1)
        for ind_trial = 1:size(Data,2)
            Angle_min = min(Angles.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir})(:,1));
            Angle_max = max(Angles.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir})(:,2));
            Diff = Angles.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir})(1,3);
            if size(Data(ind_trial).rula.(fieldnames_body1{ind_body}).part.(fieldn_dir{ind_dir}).N,2) == 1
                [~,loc] = (min(abs((floor(Angle_min):Diff:ceil(Angle_max))-...
                    (Data(ind_trial).rula.(fieldnames_body1{ind_body}).part.(fieldn_dir{ind_dir}).edges(1)+Diff/2))));
                Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).rel_N(ind_trial,:) = NaN;
                Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).rel_N(ind_trial,loc) = 1;
            else
                N_count = Data(ind_trial).rula.(fieldnames_body1{ind_body}).part.(fieldn_dir{ind_dir}).N;
                N_count = smooth(N_count,5);
            Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).rel_N(ind_trial,:) = interp1(...
                Data(ind_trial).rula.(fieldnames_body1{ind_body}).part.(fieldn_dir{ind_dir}).edges(1:(end-1)) + Diff/2,...
                N_count/sum(N_count),floor(Angle_min):Diff:ceil(Angle_max));
            Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).Angle(ind_trial,:) = ...
                floor(Angle_min):Diff:ceil(Angle_max);
            end
        end
    end
end
%%

%%
Screen = get(0,'ScreenSize');
for ind_body = 1:size(fieldnames_body,1)
    for ind_side = 1:2
    fieldn_dir = fieldnames(Data(1).rula.(fieldnames_body{ind_body}).(Side_name{ind_side}).part);
    for ind_dir = 1:size(fieldn_dir,1)
%         for ind_trial = 1:size(Data,2)
        figure(ind_body)
        set(ind_body,'Position',Screen)
        subplot(2,size(fieldn_dir,1),ind_dir)
        Limits = Data(1).rula.(fieldnames_body{ind_body}).(Side_name{ind_side}).part.(fieldn_dir{ind_dir}).limits;
        Limits(isinf(Limits)) = sign(Limits(isinf(Limits)))*200;
        for ind_limit = 1:size(Limits,1)
            patch([Limits(ind_limit,1) Limits(ind_limit,2) ...
                Limits(ind_limit,2) Limits(ind_limit,1)],...
                [0 0 1 1],[1 1 1]*(10 - Limits(ind_limit,3))/10,'edgecolor','none')
        end
        hold on
        Data_group1 = Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).rel_N(...
            ismember(ConditionTable_loaded.Condition2,'K1'),:);
        Data_group2 = Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).rel_N(...
            ismember(ConditionTable_loaded.Condition2,'K2'),:);
        Data_group1(isnan(Data_group1)) = 0;
        Data_group2(isnan(Data_group2)) = 0;
        Norm1 = nansum(prctile(Data_group1,50));
        Norm2 = nansum(prctile(Data_group2,50));
        h(1) =plot(Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),...
            prctile(Data_group1,50)./Norm1,'Color',[89 83 1]/255,'linewidth',2);
        h(2) =plot(Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),...
            prctile(Data_group2,50)./Norm2,'Color',[185 191 3]/255,'linewidth',2);
        plot(Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),...
            prctile(Data_group1,25)./Norm1,'Color',[89 83 1]/255);
        plot(Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),...
            prctile(Data_group1,75)./Norm1,'Color',[89 83 1]/255);
        plot(Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),...
            prctile(Data_group2,25)./Norm2,'Color',[185 191 3]/255);
        plot(Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),...
            prctile(Data_group2,75)./Norm2,'Color',[185 191 3]/255);
        if ind_trial == size(Data,2)
            hold off
        end
        
        

                legend(h,{'K1','K2'})

        ylabel('rel occurance []')
        xlabel('Angle [deg]')
        if ind_body == 2
            if ind_dir == 2
        xlabel('Position [m]')
            end
        end
            
        xlim([Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).Angle(1) ...
            Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).Angle(end)]);
        ylim([0 max(max(prctile(Data_group1,75)/Norm1),max(prctile(Data_group2,75)/Norm2))]);
        title([fieldnames_body{ind_body}  '_' Side_name{ind_side} ' ' fieldn_dir{ind_dir}],'Interpreter','none')
        
        tmp_xtick{ind_body,ind_dir} = get(gca,'xtick');
        tmp_xtick_label{ind_body,ind_dir} = get(gca,'xticklabel');
        tmp_xlim{ind_body,ind_dir} = get(gca,'xlim');
%         yA = Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),
%             prctile(Data_group1,75);
%         yB = Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),
%             prctile(Data_group2,75);
%
subplot(2,size(fieldn_dir,1),size(fieldn_dir,1)+ind_dir)

alpha      = 0.05;
two_tailed = false;
iterations = 1000;
        Data_group1_noNaN = Data_group1;
        Data_group1_noNaN(isnan(Data_group1_noNaN)) = 0;
        Data_group2_noNaN = Data_group2;
        Data_group2_noNaN(isnan(Data_group2_noNaN)) = 0;
        
snpm = spm1d.stats.nonparam.ttest2(Data_group1_noNaN, Data_group2_noNaN);
spm_results(ind_body,ind_side,ind_dir).snpmi = snpm.inference(alpha, 'two_tailed', two_tailed,'iterations',1000);

Stats.p_vals{ind_body,ind_side,ind_dir} = spm_results(ind_body,ind_side,ind_dir).snpmi.p;
Stats.N_vals(ind_body,ind_side,ind_dir) = size(spm_results(ind_body,ind_side,ind_dir).snpmi.z,2);

% disp('Non-Parametric results')
% disp( snpmi )
spm_results(ind_body,ind_side,ind_dir).snpmi.plot();  
spm_results(ind_body,ind_side,ind_dir).snpmi.plot_threshold_label();  
spm_results(ind_body,ind_side,ind_dir).snpmi.plot_p_values();
set(gca,'xtick',tmp_xtick{ind_body,ind_dir}-...
    min(Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).Angle(ind_trial,:)),...
    'XTicklabel',tmp_xtick_label{ind_body,ind_dir},'xlim',tmp_xlim{ind_body,ind_dir} - ...
    min(Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).Angle(ind_trial,:)))
        if ind_body == 2
                if ind_dir == 2
set(gca,'xtick',(tmp_xtick{ind_body,ind_dir}-...
    min(Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).Angle(ind_trial,:)))*100,...
    'XTicklabel',tmp_xtick_label{ind_body,ind_dir},'xlim',(tmp_xlim{ind_body,ind_dir} - ...
    min(Angle_int.(fieldnames_body{ind_body}).(Side_name{ind_side}).(fieldn_dir{ind_dir}).Angle(ind_trial,:)))*100)
                end
        end



    end
    if ~exist('results','dir')
        mkdir('results')
    end
        exportgraphics(gcf,['results/Group_comp_K1_K2_' ...
            fieldnames_body{ind_body} '_' Side_name{ind_side} '.png'])
        saveas(gcf,['results/Group_comp_K1_K2_' ...
            fieldnames_body{ind_body} '_' Side_name{ind_side} '.svg'])

        close all
    end
end

%%
ind_side = 1;
for ind_body = 1:size(fieldnames_body1,1)
    fieldn_dir = fieldnames(Data(1).rula.(fieldnames_body1{ind_body}).part);
    for ind_dir = 1:size(fieldn_dir,1)
%         for ind_trial = 1:size(Data,2)
        figure(ind_body)
        set(ind_body,'Position',Screen)
        subplot(2,size(fieldn_dir,1),ind_dir)
        Limits = Data(1).rula.(fieldnames_body1{ind_body}).part.(fieldn_dir{ind_dir}).limits;
        Limits(isinf(Limits)) = sign(Limits(isinf(Limits)))*200;
        for ind_limit = 1:size(Limits,1)
            patch([Limits(ind_limit,1) Limits(ind_limit,2) ...
                Limits(ind_limit,2) Limits(ind_limit,1)],...
                [0 0 1 1],[1 1 1]*(10 - Limits(ind_limit,3))/10,'edgecolor','none')
        end
        hold on
        Data_group1 = Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).rel_N(...
            ismember(ConditionTable_loaded.Condition2,'K1'),:);
        Data_group2 = Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).rel_N(...
            ismember(ConditionTable_loaded.Condition2,'K2'),:);
        Data_group1(isnan(Data_group1)) = 0;
        Data_group2(isnan(Data_group2)) = 0;
        Norm1 = nansum(prctile(Data_group1,50));
        Norm2 = nansum(prctile(Data_group2,50));
        h(1) =plot(Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),...
            prctile(Data_group1,50)/Norm1,'Color',[89 83 1]/255,'linewidth',2);
        h(2) =plot(Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),...
            prctile(Data_group2,50)/Norm2,'Color',[185 191 3]/255,'linewidth',2);
        plot(Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),...
            prctile(Data_group1,25)/Norm1,'Color',[89 83 1]/255);
        plot(Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),...
            prctile(Data_group1,75)/Norm1,'Color',[89 83 1]/255);
        plot(Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),...
            prctile(Data_group2,25)/Norm2,'Color',[185 191 3]/255);
        plot(Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),...
            prctile(Data_group2,75)/Norm2,'Color',[185 191 3]/255);
        if ind_trial == size(Data,2)
            hold off
        end
                legend(h,{'K1','K2'})

                
                
        ylabel('rel occurance []')
        xlabel('Angle [deg]')
%         if ind_body == 1
%             if ind_dir == 2
%         xlabel('Position [m]')
%             end
%         end
            
        xlim([Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).Angle(1) ...
            Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).Angle(end)]);
        ylim([0 max(max(prctile(Data_group1,75)/Norm1),max(prctile(Data_group2,75)/Norm2))]);
        title([fieldnames_body1{ind_body}  '_' Side_name{ind_side} ' ' fieldn_dir{ind_dir}],'Interpreter','none')
        
        tmp_xtick{ind_body,ind_dir} = get(gca,'xtick');
        tmp_xtick_label{ind_body,ind_dir} = get(gca,'xticklabel');
        tmp_xlim{ind_body,ind_dir} = get(gca,'xlim');
%         yA = Angle_int.(fieldnames_body11{ind_body}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),
%             prctile(Data_group1,75);
%         yB = Angle_int.(fieldnames_body11{ind_body}).(fieldn_dir{ind_dir}).Angle(ind_trial,:),
%             prctile(Data_group2,75);
%
        subplot(2,size(fieldn_dir,1),size(fieldn_dir,1)+ind_dir)

alpha      = 0.05;
two_tailed = false;
iterations = 1000;
        Data_group1_noNaN = Data_group1;
        Data_group1_noNaN(isnan(Data_group1_noNaN)) = 0;
        Data_group2_noNaN = Data_group2;
        Data_group2_noNaN(isnan(Data_group2_noNaN)) = 0;
        
snpm = spm1d.stats.nonparam.ttest2(Data_group1_noNaN, Data_group2_noNaN);
spm_results(ind_body+4,ind_side,ind_dir).snpmi = snpm.inference(alpha, 'two_tailed', two_tailed,'iterations',1000);

Stats.p_vals{ind_body+4,ind_side,ind_dir} = spm_results(ind_body+4,ind_side,ind_dir).snpmi.p;
Stats.N_vals(ind_body+4,ind_side,ind_dir) = size(spm_results(ind_body+4,ind_side,ind_dir).snpmi.z,2);
% disp('Non-Parametric results')
% disp( snpmi )
spm_results(ind_body+4,ind_side,ind_dir).snpmi.plot();  
spm_results(ind_body+4,ind_side,ind_dir).snpmi.plot_threshold_label();  
spm_results(ind_body+4,ind_side,ind_dir).snpmi.plot_p_values();
set(gca,'xtick',tmp_xtick{ind_body,ind_dir}-...
    min(Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).Angle(ind_trial,:)),...
    'XTicklabel',tmp_xtick_label{ind_body,ind_dir},'xlim',tmp_xlim{ind_body,ind_dir} - ...
    min(Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).Angle(ind_trial,:)))
%         if ind_body == 1
%                 if ind_dir == 2
% set(gca,'xtick',(tmp_xtick{ind_body,ind_dir}-...
%     min(Angle_int.(fieldnames_body1{ind_body}).(fieldn_dir{ind_dir}).Angle(ind_trial,:)))*100,...
%     'XTicklabel',tmp_xtick_label{ind_body,ind_dir})
%                 end
%         end
    end
    if ~exist('results','dir')
        mkdir('results')
    end
    exportgraphics(gcf,['results/Group_comp_K1_K2_' ...
        fieldnames_body1{ind_body} '.png'])
%     export_fig 'results\RULA step hist 4' '-png'
    saveas(gcf,['results/Group_comp_K1_K2_' ...
        fieldnames_body1{ind_body} '.svg'])

    close all
   
end