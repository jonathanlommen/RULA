function Output = MF_calc_RULA_score(Input,Limit)

% Limit is organised from lowest angle to highest anlge. 
% 
Output = NaN*ones(size(Input));
%%
for ind_l = 1:size(Limit,1)
    Output(and(Limit(ind_l,1)<=Input,Input<Limit(ind_l,2))) = Limit(ind_l,3);
end
% plot(Output)