function [self] = RSRegression()
self.www  = 'http://www.real-statistics.com/regression/hypothesis-testing-significance-regression-line-slope/';
self.x    = [5, 23, 25, 48, 17, 8, 4, 26, 11, 19, 14, 35, 29, 4, 23]';
self.Y    = [80, 78, 60, 53, 85, 84, 73, 79, 81, 75, 68, 72, 58, 92, 65]';
self.z    = -3.67092;
self.df   = [1,13];
self.p    = 0.002822;
self.r    = -0.71343;
end