function [self] = RSFlavor()
self.www  = 'http://www.real-statistics.com/students-t-distribution/two-sample-t-test-equal-variances/';
self.YA   = [13,17,19,11,20,15,18,9,12,16]';
self.YB   = [12,8,6,16,12,14,10,18,4,11]';
self.z    = 2.176768;
self.df   = [1,18];
self.p    = 0.021526;
end