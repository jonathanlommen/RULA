function [self] = RSWeightReduction()
self.www  = 'http://www.real-statistics.com/students-t-distribution/one-sample-t-test/';
self.Y    = [23, 15, -5, 7, 1, -10, 12, -8, 20, 8, -2, -5]';
self.mu   = 0;
self.z    = 1.449255;
self.df   = [1 11];
self.p    = 0.087585;
end



